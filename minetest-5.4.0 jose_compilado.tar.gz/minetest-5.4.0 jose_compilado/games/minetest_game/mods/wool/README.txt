Minetest Game mod: wool
=======================
See license.txt for license information.

Authors of source code
----------------------
Originally by Perttu Ahola (celeron55) <celeron55@gmail.com> (MIT)
Various Minetest developers and contributors (MIT)

Authors of media (textures)
---------------------------
Cisoun (CC BY-SA 3.0):
  wool_black.png wool_brown.png wool_dark_green.png wool_green.png
  wool_magenta.png wool_pink.png wool_violet.png wool_yellow.png
  wool_blue.png wool_cyan.png wool_dark_grey.png wool_grey.png
  wool_orange.png wool_red.png wool_white.png
